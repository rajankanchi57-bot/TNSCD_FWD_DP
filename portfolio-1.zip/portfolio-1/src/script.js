function showMsg() {
  alert("Thanks for reaching out, I will get back to you soon 😊");
  return false; // Prevents page refresh
}
